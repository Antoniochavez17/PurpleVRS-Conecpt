//
//  Apple Contact.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/7/24.
//


import Foundation
import Contacts
import SwiftUI

import Contacts
import SwiftUI

class ContactsViewModel: ObservableObject {
    @Published var contacts = [CNContact]()
    
    func getContacts() {
        // Add CNContactOrganizationNameKey to fetch the company name
        let keys = [
            CNContactFormatter.descriptorForRequiredKeys(for: .fullName),
            CNContactPhoneNumbersKey as CNKeyDescriptor,
            CNContactImageDataKey as CNKeyDescriptor, // For profile picture
            CNContactOrganizationNameKey as CNKeyDescriptor // For company name
        ]
        let request = CNContactFetchRequest(keysToFetch: keys)
        
        let contactStore = CNContactStore()
        contacts = [CNContact]()
        do {
            try contactStore.enumerateContacts(with: request) { (contact, stop) in
                self.contacts.append(contact)
            }
        } catch {
            print("unable to fetch contacts")
        }
    }
}

extension CNContact {
    var getDisplayName: String {
        var name = self.givenName
        
        if !self.middleName.isEmpty {
            name += " \(self.middleName)"
        }
        
        if !self.familyName.isEmpty {
            name += " \(self.familyName)"
        }
        
        if !self.nameSuffix.isEmpty {
            name += " \(self.nameSuffix)"
        }
        return name
    }
    
    // Fetch the contact's profile image if available
    var profileImage: UIImage? {
        if let imageData = self.imageData {
            return UIImage(data: imageData)
        }
        return nil // Return nil if no profile image
    }
    
    // Fetch the company name
    var companyName: String {
        return self.organizationName ?? "" // Return "No Company" if none exists
    }
}

import SwiftUI
import Contacts
struct ContactView: View {
    @StateObject var viewModel: ContactsViewModel
    @State var queryString: String = ""
    
    var body: some View {
        NavigationView {
            List {
                Section {
                    MyCard
                        .frame(height: 50, alignment: .leading)
                }
                
                Section {
                    ForEach(searchResult, id: \.identifier) { contact in
                        NavigationLink(destination: ContactsDetailView(contactinfo: contact)) {
                            HStack {
                                // Profile image or placeholder
                                if let image = contact.profileImage {
                                    Image(uiImage: image)
                                        .resizable()
                                        .scaledToFill()
                                        .frame(width: 50, height: 50)
                                        .clipShape(Circle())
                                } else {
                                    Image(systemName: "person.crop.circle.fill")
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 50, height: 50)
                                }
                                
                                VStack(alignment: .leading) {
                                    Text(contact.getDisplayName)
                                        .font(.headline)
                                    
                                    Text(contact.companyName)
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                            }
                        }
                    }
                }
            }
            .listStyle(.insetGrouped)
            .searchable(text: $queryString, placement: .navigationBarDrawer(displayMode: .always))
            .navigationTitle("Contacts")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Groups") {
                        // Handle groups button action
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        // Handle add new contact button action
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
        }
        .onAppear {
            viewModel.getContacts()
        }
    }
    
    var MyCard: some View {
        HStack {
            Image("mycard_placeholder")
                .resizable()
                .clipShape(Circle())
                .scaledToFit()
                .frame(width: 50, height: 50)
            VStack(alignment: .leading) {
                Text("Imari Yamamto")
                    .font(.headline)
                Text("My Card")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
    }
    
    var searchResult: [CNContact] {
        if queryString.isEmpty {
            return viewModel.contacts
        }
        return viewModel.contacts.filter { contact in
            ("\(contact.givenName) \(contact.middleName) \(contact.familyName) \(contact.nameSuffix)").contains(queryString)
        }
    }
}


import SwiftUI
import Contacts

struct ContactsDetailView: View {
    var contactinfo: CNContact?
    
    init(contactinfo: CNContact?) {
        self.contactinfo = contactinfo
        UITableView.appearance().sectionHeaderHeight = 0
    }
    
    var body: some View {
        NavigationView {
            VStack {
                headerView
                contactOptionView
                    .frame(height: 60)
                formView
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Edit") {
                        // Add edit functionality here
                    }
                }
            }
        }
    }
    
    private var headerView: some View {
        VStack {
            if let imageData = contactinfo?.imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .clipShape(Circle())
                    .scaledToFit()
                    .frame(width: 130, height: 130)
            } else {
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 130, height: 130)
            }
            
            Text(contactinfo?.getDisplayName ?? "Full Name")
                .font(.largeTitle)
            
            Text(contactinfo?.companyName ?? "Company") // Show company name
                .font(.title3)
                .frame(width: 400, height: 40)
                .padding(.top, -20)
        }
        .frame(maxWidth: .infinity, maxHeight: 250) // Adjust to fit the background
        .background(
            Color.gray.opacity(0.1) // Background color, replace with profile background image if needed
                .clipShape(Circle())
                .scaledToFit()
                .frame(width: 100, height: 100)
                .padding(.top, -90)
                .blur(radius: 60) // Apply blur effect
        )
    }
    
    private var contactOptionView: some View {
        HStack(spacing: 20) { // Add spacing between the options
            // Favorite Option
            VStack {
                Image(systemName: "star.fill")
                    .font(.system(size: 24)) // Adjust icon size
                Text("Favorite")
                    .font(.headline) // Use headline for the text style
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, maxHeight: 30) // Adjust height for square shape
            .foregroundColor(.blue)
            .padding()
            .background(Color.gray.opacity(0.2))
            .cornerRadius(12) // Rounded corners
            .shadow(radius: 5) // Add shadow for depth

            // Call Option
            VStack {
                Image(systemName: "phone.fill")
                    .font(.system(size: 24)) // Adjust icon size
                Text("Call")
                    .font(.headline)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, maxHeight: 30)
            .foregroundColor(.blue)
            .padding()
            .background(Color.gray.opacity(0.2))
            .cornerRadius(12)
            .shadow(radius: 5)

            // Signmail Option
            VStack {
                Image(systemName: "video.fill")
                    .font(.system(size: 24)) // Adjust icon size
                Text("Signmail")
                    .font(.headline)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity, maxHeight: 30)
            .foregroundColor(.blue)
            .padding()
            .background(Color.gray.opacity(0.2))
            .cornerRadius(12)
            .shadow(radius: 5)
        }
        .padding(.horizontal, 16) // Horizontal padding for HStack
        .padding(.vertical, 8) // Vertical padding for top and bottom
    }
    
    var formView: some View {
        Form {
            Section {
                if let phoneNumber = contactinfo?.phoneNumbers {
                    ForEach(phoneNumber, id: \.self) { result in
                        VStack(alignment: .leading) {
                            if let label = result.label {
                                let localizedLabel = CNLabeledValue<CNPhoneNumber>.localizedString(forLabel: label)
                                Text(localizedLabel)
                            }
                            Text(result.value.stringValue)
                                .foregroundColor(Color.blue)
                        }
                        .padding(8)
                    }
                }
                
            }
            
            Section {
                Button("Call History") {
                    // Handle call history action
                }
                
                Button("Share Contact") {
                    // Handle share contact action
                }
                
                Button("Add to Favorite") {
                    // Handle add to favorite action
                }
            }
            
            Section {
                Button("Block this Caller") {
                    // Handle block caller action
                }
                .foregroundColor(Color.red)
            }
        }
    }
}
