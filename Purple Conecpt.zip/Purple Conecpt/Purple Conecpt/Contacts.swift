//
//  Contacts.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/7/24.
//

import SwiftUI

struct ContactsView: View {
    @State private var selectedCategory: Int = 0  // Track the selected picker value
    
    var body: some View {
        NavigationView {
            VStack {
                // Display the selected view based on the category picked
                switch selectedCategory {
                case 0:
                    FavoriteView()
                case 1:
                    ContactView(viewModel: ContactsViewModel())
                case 2:
                    ContactView(viewModel: ContactsViewModel())
                default:
                    FavoriteView()
                }
            }
    
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    // Centered Picker in the navigation bar
                    Picker("", selection: $selectedCategory) {
                        // 1. Favorites (with SF symbol)
                        Label("Favorites", systemImage: "star.fill")
                            .tag(0)
                        // 2. Apple Contacts (with SF symbol)
                        Label("Apple Contacts", systemImage: "apple.logo")
                            .tag(1)
                        // 3. Purple Contacts (with SF symbol)
                        Label("Purple Contacts", systemImage: "z.circle.fill")
                            .tag(2)
                    }
                    .pickerStyle(SegmentedPickerStyle()) // Make the picker look like tabs
                    .frame(width: 200) // Optional: Adjust the width of the picker
                }
            }
        }
    }
}


struct RecentContactModel {
    
    enum CallType {
        case missed
        case received
        case dialed
    }
    var id = UUID()
    var contactName:String
    var callTime:String
    var callType: CallType
    var contactLabel:String
}

extension RecentContactModel {
    static var mockData:[RecentContactModel] {
        return [
            RecentContactModel(contactName: "Tim Cook", callTime: "10:30 AM", callType: .received, contactLabel: "phone"),
            RecentContactModel(contactName: "Bae 🐝", callTime: "10:00 AM", callType: .dialed, contactLabel: "phone"),
            RecentContactModel(contactName: "Mark Zuckerberg", callTime: "Yesterday", callType: .received, contactLabel: "phone"),
            RecentContactModel(contactName: "Arun", callTime: "Yesterday", callType: .missed, contactLabel: "phone"),
            RecentContactModel(contactName: "+91 7779876878", callTime: "Yesterday", callType: .received, contactLabel: "phone"),
            RecentContactModel(contactName: "David Taylor", callTime: "Yesterday", callType: .dialed, contactLabel: "phone"),
            RecentContactModel(contactName: "Anand Kumar (2)", callTime: "Yesterday", callType: .missed, contactLabel: "phone"),
            RecentContactModel(contactName: "Akka", callTime: "Yesterday", callType: .received, contactLabel: "phone"),
        ]
    }
}



struct PurpleContact: View {
    var body: some View {
        VStack {
            Text("Purple Contacts")
                .font(.title)
                .fontWeight(.bold)
            // You can add actual contacts here or placeholders
            Text("Purple Wolf")
            Text("Violet Moon")
        }
        .padding()
    }
}


struct ContactView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContactsView()
              
        }
    }
}



