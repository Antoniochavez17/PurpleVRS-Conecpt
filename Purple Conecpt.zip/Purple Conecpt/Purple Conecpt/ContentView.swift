//
//  ContentView.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/6/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            // Contacts Tab
            ContactsView()
                .tabItem {
                    Image(systemName: "person.text.rectangle.fill")
                    Text("Contacts")
                }

            // History Tab
            RecentView()
                .tabItem {
                    Image(systemName: "clock.fill")
                    Text("Recent")
                }

            // Dial Tab
            DialView()
                .tabItem {
                    Image(systemName: "circle.grid.3x3.fill")
                    Text("Dial")
                }

            // Sign Mail Tab
            SignMailView(contacts: [
                SignMailContactModel(contactName: "Alice Johnson", contactLabel: "Interpreter", videoThumbnail: "video_thumbnail"),
                SignMailContactModel(contactName: "Bob Smith", contactLabel: "Supporter", videoThumbnail: "video_thumbnail")
            ])
                .tabItem {
                    Image(systemName: "person.crop.square.badge.video")
                    Text("Sign Mail")
                }

            // Settings Tab
            SettingsView()
                .tabItem {
                    Image(systemName: "gear")
                    Text("Settings")
                }
        }
    }
}

#Preview {
    ContentView()
}
