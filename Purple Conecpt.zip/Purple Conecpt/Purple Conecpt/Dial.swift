//
//  Dial.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/6/24.
//

import SwiftUI

struct DialPadModel: Hashable, Identifiable {
    var id = UUID()
    var dialNumber: String
    var dialValue: String
}

struct DialView: View {
    @State var dialedNumber:String = ""
    
    @Environment(\.colorScheme) var colorScheme
    
    var dialInput = [
        [
            DialPadModel(dialNumber: "1", dialValue: ""),
            DialPadModel(dialNumber: "2", dialValue: "ABC"),
            DialPadModel(dialNumber: "3", dialValue: "DEF")],
        
        [
            DialPadModel(dialNumber: "4", dialValue: "GHI"),
            DialPadModel(dialNumber: "5", dialValue: "JKL"),
            DialPadModel(dialNumber: "6", dialValue: "MNO")],
        [
            DialPadModel(dialNumber: "7", dialValue: "PQRS"),
            DialPadModel(dialNumber: "8", dialValue: "TUV"),
            DialPadModel(dialNumber: "9", dialValue: "WXYZ")],
        [
            DialPadModel(dialNumber: "*", dialValue: ""),
            DialPadModel(dialNumber: "0", dialValue: "+"),
            DialPadModel(dialNumber: "#", dialValue: "")]]
    
    var body: some View {
        VStack {
            Spacer()
            TextField("", text: $dialedNumber, prompt: nil)
                .font(Font.largeTitle)
                .multilineTextAlignment(.center)
                .foregroundColor(colorScheme == .dark ? .white : .white)
            if (dialedNumber.count) != 0 {
                Button("Add Number") {
                    
                }
            }
            Spacer()
            VStack(alignment: .center, spacing: 20) {
                ForEach(dialInput, id: \.self) { rowValues in
                    HStack(alignment: .center, spacing: 20) {
                        ForEach(rowValues, id: \.id) { value in
                            Button() {
                                dialedNumber += value.dialNumber
                            } label: {
                                VStack(spacing: 0) {
                                    Text(value.dialNumber)
                                        .font(.largeTitle)
                                        .foregroundColor(colorScheme == .dark ? .white : .white)
                                    
                                    Text(value.dialValue)
                                        .foregroundColor(Color.gray)
                                        .font(.caption2)
                                }
                                
                                .frame(width: 80, height: 80, alignment: .center)
                                .background(Color.secondary.opacity(0.3))
                                .cornerRadius(40)
                            }
                        }
                    }
                }
                
                HStack {
                    Button() {
                        
                    } label: {
                        Image(systemName:"phone.fill")
                            .resizable()
                            .frame(width: 30, height: 30, alignment: .center)
                            .foregroundColor(Color.white)
                    }
                    .frame(width: 80, height: 80, alignment: .center)
                    .background(Color.green)
                    .cornerRadius(40)
                    .padding(.leading,(dialedNumber.count) != 0  ? 60 : 0)
                    
                    if (dialedNumber.count) != 0 {
                        Button() {
                            dialedNumber = String(dialedNumber.dropLast())
                        } label: {
                            Image(systemName:"delete.backward.fill")
                                .resizable()
                                .frame(width: 25, height: 20, alignment: .center)
                                .foregroundColor(Color.gray)
                                .padding(.leading, 30)
                        }
                        
                    }
                }
                
            }
        }
        .padding(.bottom, 20)
    }
    
    var rowView: some View {
        Text("")
    }
}

struct DialPadView_Previews: PreviewProvider {
    static var previews: some View {
        DialView()
            .preferredColorScheme(.light)
    }
}

