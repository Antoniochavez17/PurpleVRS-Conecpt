//
//  FavoriteContacts.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/7/24.
//

import SwiftUI


struct FavoriteContactModel {
    var id = UUID()
    var contactName:String
    var contactLabel:String
    var contactImage:String?
}

extension FavoriteContactModel {
    static var mockData:[FavoriteContactModel] {
        return [
            FavoriteContactModel(contactName: "Rakesh", contactLabel: "office", contactImage: "user_1"),
            FavoriteContactModel(contactName: "Dad", contactLabel: "phone", contactImage: nil),
            FavoriteContactModel(contactName: "Mom", contactLabel: "office", contactImage: nil),
            FavoriteContactModel(contactName: "Albert", contactLabel: "phone", contactImage: "user_2"),
            FavoriteContactModel(contactName: "Bae🐝", contactLabel: "home", contactImage: "mycard_placeholder")
        ]
    }
}


struct FavoriteView: View {
    var body: some View {
        NavigationView {
            listView
            .toolbar {
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Edit") {
                        
                    }
                }
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button {
                        
                    } label: {
                        Image(systemName: "plus")
                    }
                    
                }
            }
        }
        
            
    }
    
    var listView: some View {
        List {
            let contacts = FavoriteContactModel.mockData
            ForEach(contacts, id: \.id) { contact in
                FavouriteRow(contact: contact)
            }
        }
        .listStyle(.plain)
        .navigationTitle("Favorite")
    }
}

struct FavouriteRow: View {
    var contact: FavoriteContactModel
    
    var body: some View {
        HStack {
            if let image = contact.contactImage {
                Image("mycard_placeholder")
                    .resizable()
                    .clipShape(Circle())
                    .scaledToFit()
                    .frame(width: 30, height: 30)
             
            }else{
                Image("mycard_placeholder")
                    .resizable()
                    .clipShape(Circle())
                    .scaledToFit()
                    .frame(width: 30, height: 30)
            }
            
            
            
            VStack(alignment: .leading, spacing: 3) {
                Text(contact.contactName)
                    .font(Font.headline)
                    .fontWeight(.semibold)
                HStack {
                    Image(systemName:"phone.fill")
                        .resizable()
                        .frame(width: 12, height: 12, alignment: .center)
                        .foregroundColor(Color.gray)
                    Text(contact.contactLabel)
                        .foregroundColor(Color.secondary)
                }
            }
            Spacer()
            Button(action: {
                
            }, label: {
                Image(systemName:"info.circle")
                    .resizable()
                    .frame(width: 22, height: 22, alignment: .center)
                    .foregroundColor(Color.accentColor)
            })
        }
    }
    
}
