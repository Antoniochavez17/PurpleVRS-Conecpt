//
//  Purple_ConecptApp.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/6/24.
//

import SwiftUI

@main
struct Purple_ConecptApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
