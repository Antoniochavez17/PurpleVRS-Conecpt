//
//  Recent.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/7/24.
//

import SwiftUI

struct RecentView: View {

    @State private var callType = 0
    @State private var isEditList:Bool = false

    var recentList = RecentContactModel.mockData
    
    var getRecentCallList:[RecentContactModel] {
        if callType == 0 {
            return recentList
        }else{
            return recentList.filter { model in
                return model.callType == .missed
            }
        }
    }
    
    var body: some View {
        NavigationView {
            let contactInfo = getRecentCallList
            List {
                ForEach(contactInfo, id: \.id) { contact in
                    RecentListRow(contactInfo: contact)
                }.onDelete(perform: delete)
            }
            
            .listStyle(.insetGrouped)
            .navigationTitle("Recents")
            .toolbar {
                EditButton()
            }
            .toolbar {
                ToolbarItem(placement: .principal) {
                    Picker("", selection: $callType) {
                        Text("All")
                            .tag(0)
                        Text("Missed")
                            .tag(1)
                    }
                    .pickerStyle(.segmented)
                    .frame(width: 200)
                }
            }
        }
    }
    
    func delete(at offsets: IndexSet) {
//        recentList.remove(atOffsets: offsets)
    }
}


struct RecentListRow: View {
    var contactInfo: RecentContactModel
    
    var body: some View {
        HStack {
            if contactInfo.callType == .dialed {
                HStack {
                    Image("mycard_placeholder")
                        .resizable()
                        .clipShape(Circle())
                        .scaledToFit()
                        .frame(width: 30, height: 30)
                    
                }
            }else{
                HStack {
                    Image("mycard_placeholder")
                        .resizable()
                        .clipShape(Circle())
                        .scaledToFit()
                        .frame(width: 30, height: 30)
                  
                }
            }
            
            
            VStack(alignment: .leading, spacing: 0) {
                Text(contactInfo.contactName)
                    .font(Font.headline)
                    .fontWeight(.semibold)
                    .foregroundColor(contactInfo.callType == .missed ? .red : .white)
                
                Text(contactInfo.contactLabel)
                    .foregroundColor(Color.secondary)
            }
            
            Spacer()
            Text(contactInfo.callTime)
                .foregroundColor(Color.secondary)
            Image(systemName: "info.circle")
                .resizable()
                .frame(width: 22, height: 22, alignment: .center)
                .foregroundColor(Color.accentColor)
        }
    }
}

