//
//  Settings.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/7/24.
//
import SwiftUI

struct SettingsView: View {
    
    
    @State private var preferLanguage = 0
    @State private var preferLanguage1 = 0
    @State private var preferLanguage2 = 0
    
    @State private var showGreeting = true
    
    var body: some View {
        NavigationStack {
            List {
                
                Section {
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            Image("mycard_placeholder")
                                .resizable()
                                .clipShape(Circle())
                                .scaledToFit()
                                .frame(width: 50, height: 50)
                            VStack(alignment: .leading) {
                                Text("Imari Yamamto")
                                    .font(.headline)
                                Text("928-452-3452")
                                    .font(.subheadline)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.red)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "square.and.arrow.up.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("Log out")
                        }
                    }
                    
                }
                
                
                Section {
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.orange)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "newspaper.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("Term & Conditions")
                        }
                    }
                    
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.blue)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "hand.raised.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("Privacy Policy")
                        }
                    }
                    
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.pink)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "heart.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("Rate Purple VRS")
                        }
                    }
                    
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.purple)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "questionmark.diamond.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("Help Center")
                        }
                    }
                }
                
                Section {
                    
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.gray)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "lightbulb.led.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("POP Light")
                        }

                    }
                    
                    
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.red)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "bell.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("Notification")
                        }
                    }
                    
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.red)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "sos")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("SOS")
                        }
                    }
                    
                 
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.indigo)
                                    .frame(width: 25, height: 25)
                                
                                if showGreeting {
                                    Image(systemName: "microphone.slash")
                                        .font(.footnote)
                                        .foregroundColor(.white)
                                } else {
                                    Image(systemName: "microphone.fill")
                                        .font(.footnote)
                                        .foregroundColor(.white)
                                }
                                
                                
                                    
                            }
                            .padding(.leading, -5)
                            
                            Toggle("Mute Receiving Call", isOn: $showGreeting)
                            
                          
                            
                    }
                    
                    
                    
                           HStack {
                               ZStack {
                                   RoundedRectangle(cornerRadius: 6)
                                       .fill(Color.green)
                                       .frame(width: 25, height: 25)
                                   
                                   if showGreeting {
                                       Image(systemName: "video.slash.fill")
                                           .font(.footnote)
                                           .foregroundColor(.white)
                                   } else {
                                       Image(systemName: "video.fill")
                                           .font(.footnote)
                                           .foregroundColor(.white)
                                   }
                                   
                                   
                                       
                               }
                               .padding(.leading, -5)
                               
                               Toggle("Private Camera Receiving Call", isOn: $showGreeting)
                               
                             
                               
                       }
                    
                    
               
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.blue)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "globe")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                          
                                Picker("Language", selection: $preferLanguage){
                                       Text("English").tag(0)
                                       Text("Spanish").tag(1)
                                   }.pickerStyle(.automatic)
                                
                         
                            
                        }
                 
                    HStack {
                        ZStack {
                            RoundedRectangle(cornerRadius: 6)
                                .fill(Color.purple)
                                .frame(width: 25, height: 25)
                            Image(systemName: "person.2.wave.2.fill")
                                .font(.footnote)
                                .foregroundColor(.white)
                        }
                        .padding(.leading, -5)
                        Picker("Interpreter Speak", selection: $preferLanguage1){
                               Text("English").tag(0)
                               Text("Spanish").tag(1)
                           }.pickerStyle(.automatic)
                        
                    }
                    
                    
                    
                    NavigationLink(destination: SettingsDetailView()) {
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.red)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "person.slash.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Text("Block Contacts")
                        }
                    }
                    
                }
                
                
                
                
                
                Section( footer: footerView) {
               
                        HStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 6)
                                    .fill(Color.purple)
                                    .frame(width: 25, height: 25)
                                Image(systemName: "moon.fill")
                                    .font(.footnote)
                                    .foregroundColor(.white)
                            }
                            .padding(.leading, -5)
                            Picker("Appearance", selection: $preferLanguage){
                                   Text("Dark").tag(0)
                                   Text("Light").tag(1)
                               }.pickerStyle(.automatic)
                            
                        }
                }
                
               
            }
            .listStyle(InsetGroupedListStyle())
            .navigationBarTitle("Settings")
            .navigationBarTitleDisplayMode(.large)
            
            
        }
    }
    
    var footerView: some View {
           VStack {
               VStack(spacing: 20) {
                   // Logo Images with Divider
                   HStack {
                       Spacer()
                       
                       // First Logo
                       Image("logo1")
                           .resizable()
                           .scaledToFit()
                           .frame(width: 100, height: 100)
                       
                       Divider()
                           .frame(height: 50) // Adjusts divider height to match logos
                       
                       // Second Logo
                       Image("logo2")
                           .resizable()
                           .scaledToFit()
                           .frame(width: 50, height: 50)
                       
                       Spacer()
                   }
               
               }
               Text("Copyright© 2020-2023")
                   .foregroundColor(.secondary)
                   .font(.system(size: 15))
                   .padding(.top,-20)
           }
      
       }

    
}



struct SettingsDetailView: View {
    var body: some View {
        Text("Here is the settings view")
    }
    
}


struct LightHueSaturationView: View {
    @State private var hue: Double = 0.0
    @State private var saturation: Double = 1.0

    var body: some View {
        VStack(spacing: 30) {
            // Light Image with Hue and Saturation Adjustments
            Image("light") // Replace with your light image name
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .colorMultiply(Color(hue: hue, saturation: saturation, brightness: 1.0))

            // Controls for Hue & Saturation
            VStack(alignment: .leading, spacing: 15) {
                Text("Adjust Light Color")
                    .font(.headline)
                
                SliderControl(value: $hue, label: "Hue", range: 0...1)
                SliderControl(value: $saturation, label: "Saturation", range: 0...1)
            }
            .padding()
            .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemGray6)))
            .shadow(radius: 4)
        }
        .padding()
    }
}

// Custom Slider Control View
struct SliderControl: View {
    @Binding var value: Double
    var label: String
    var range: ClosedRange<Double>

    var body: some View {
        VStack(alignment: .leading) {
            Text("\(label): \(String(format: "%.2f", value))")
                .font(.subheadline)
                .foregroundColor(.gray)
            Slider(value: $value, in: range)
                .accentColor(Color.white)
        }
    }
}

struct LightHueSaturationView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}

