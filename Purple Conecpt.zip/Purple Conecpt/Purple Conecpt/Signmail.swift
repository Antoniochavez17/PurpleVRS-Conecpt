//
//  Signmail.swift
//  Purple Conecpt
//
//  Created by Antonio Adrian Chavez on 11/7/24.
//

import SwiftUI

struct SignMailView: View {
    var contacts: [SignMailContactModel] // List of contact models

    var body: some View {
        NavigationView {
            List(contacts, id: \.contactName) { contact in
                SignMailRow(contactInfo: contact)
                    .frame(height: 50)
            }
            
            .navigationTitle("Sign Mail")
            .toolbar {
                            ToolbarItem(placement: .navigationBarTrailing) {
                                Button(action: {
                                    // Handle "New Signmail" button action
                                    print("New Signmail Button Tapped")
                                }) {
                                    Text("New Signmail")
                                }
                            }
                            
                        }
        }
    }
}

struct SignMailRow: View {
    var contactInfo: SignMailContactModel
    
    var body: some View {
        HStack {
            // Video Thumbnail with Play Button inside it
            ZStack {
                // Replace with your actual video image or thumbnail
                Image(contactInfo.videoThumbnail) // Example: Replace with actual image name
                    .resizable()
                    .scaledToFill()
                    .frame(width:65, height: 40)
                    .cornerRadius(10)  // Smooth rounded corners

                // Play button symbol inside the thumbnail image
                Image(systemName: "play.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 25, height: 25)
                    .foregroundColor(.white)
                    .background(Circle().fill(Color.black.opacity(0.5))) // Background for the play button
            }
            .frame(width: 70, height: 70) // Set the thumbnail size

            // VStack for the name and role (Interpreter/Supporter)
            VStack(alignment: .leading, spacing: 0) {
                Text(contactInfo.contactName)
                    .font(Font.headline)
                    .fontWeight(.semibold)
                
                Text(contactInfo.contactLabel) // Interpreter or Supporter
                    .foregroundColor(Color.secondary)
            }

            Spacer()

            Text("11:00 PM")
                .foregroundStyle(.gray)
            // Info button at the far right
            Image(systemName: "info.circle")
                .resizable()
                .frame(width: 22, height: 22, alignment: .center)
                .foregroundColor(Color.accentColor)
        }
        .padding(.vertical, 8)
    }
}

struct SignMailContactModel {
    var contactName: String
    var contactLabel: String // "Interpreter" or "Supporter"
    var videoThumbnail: String // Image name for the video thumbnail
}

struct SignMailView_Previews: PreviewProvider {
    static var previews: some View {
        SignMailView(contacts: [
            SignMailContactModel(contactName: "Alice Johnson", contactLabel: "Interpreter", videoThumbnail: "video_thumbnail"),
            SignMailContactModel(contactName: "Bob Smith", contactLabel: "Supporter", videoThumbnail: "video_thumbnail")
        ])
        .previewLayout(.sizeThatFits)
    }
}
