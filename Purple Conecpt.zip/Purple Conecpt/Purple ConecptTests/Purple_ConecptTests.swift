//
//  Purple_ConecptTests.swift
//  Purple ConecptTests
//
//  Created by Antonio Adrian Chavez on 11/6/24.
//

import Testing

struct Purple_ConecptTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
